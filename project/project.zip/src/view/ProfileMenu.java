package view;

public class ProfileMenu extends Menu{
}
