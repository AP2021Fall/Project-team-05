package view;

public class TeamMenu extends Menu{
}
