package view.Team;

public class Scoreboard {
}
