package view;

public class NotificationBar extends Menu{
}
