package view;

public class TasksMenu extends Menu{
}
