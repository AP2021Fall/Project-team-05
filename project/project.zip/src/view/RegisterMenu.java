package view;

public class RegisterMenu extends Menu{
}
