package view;

public abstract class Menu {
}
