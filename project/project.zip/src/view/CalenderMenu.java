package view;

public class CalenderMenu extends Menu{
}
